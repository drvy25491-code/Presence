package com.example.attendancecontrol

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    companion object {
        val groupList = mutableListOf<Group>(
            Group(1, "ИС-21")
        )
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Student.load(this)


        findViewById<Button>(R.id.btnStudents).setOnClickListener {
            val intent = Intent(this, StudentsActivity::class.java)
            startActivity(intent)
        }
        findViewById<Button>(R.id.btnAttendance).setOnClickListener {
            startActivity(Intent(this, LessonSetupActivity::class.java))
        }
        findViewById<Button>(R.id.btnStatistics).setOnClickListener {
            Toast.makeText(this, "заготовка", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnAddGroup).setOnClickListener {
            val intent = Intent(this, GroupsActivity::class.java)
            startActivity(intent)
        }
    }
}
