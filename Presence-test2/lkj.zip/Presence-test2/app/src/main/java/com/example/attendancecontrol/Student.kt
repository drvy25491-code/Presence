package com.example.attendancecontrol

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Student(
    val id: Int,
    val firstName: String,
    val lastName: String,
    val groupName: String
) {
    companion object {
        val studentList = mutableListOf<Student>()
        val attendanceList = mutableListOf<Attendance>()

        fun save(context: Context) {
            val prefs = context.getSharedPreferences("app_json_data", Context.MODE_PRIVATE)

            val sArray = JSONArray()
            for (s in studentList) {
                sArray.put(JSONObject().apply {
                    put("id", s.id)
                    put("firstName", s.firstName)
                    put("lastName", s.lastName)
                    put("groupName", s.groupName)
                })
            }

            val aArray = JSONArray()
            for (a in attendanceList) {
                aArray.put(JSONObject().apply {
                    put("studentId", a.studentId)
                    put("lessonDate", a.lessonDate)
                    put("subject", a.subject)
                    put("status", a.status)
                })
            }

            prefs.edit()
                .putString("students", sArray.toString())
                .putString("attendance", aArray.toString())
                .apply()
        }

        fun load(context: Context) {
            val prefs = context.getSharedPreferences("app_json_data", Context.MODE_PRIVATE)

            prefs.getString("students", null)?.let { str ->
                studentList.clear()
                val arr = JSONArray(str)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    studentList.add(
                        Student(o.getInt("id"), o.getString("firstName"), o.getString("lastName"), o.getString("groupName"))
                    )
                }
            }

            prefs.getString("attendance", null)?.let { str ->
                attendanceList.clear()
                val arr = JSONArray(str)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    attendanceList.add(
                        Attendance(o.getInt("studentId"), o.getString("lessonDate"), o.getString("subject"), o.getString("status"))
                    )
                }
            }
        }
    }
}
