package com.example.attendancecontrol

data class Group(
    val id: Int,
    val name: String
)