package com.example.attendancecontrol

data class Attendance(
    val studentId: Int,
    val lessonDate: String,
    val subject: String,
    val status: String
)