package com.example.attendancecontrol

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object AppData {
    val studentList = mutableListOf<Student>()
    val attendanceList = mutableListOf<Attendance>()

    private const val PREFS_NAME = "attendance_json_storage"
    private const val KEY_STUDENTS = "students_json"
    private const val KEY_ATTENDANCE = "attendance_json"

    // Сохранение обоих списков в формате JSON
    fun save(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        val studentsJson = JSONArray()
        for (s in studentList) {
            val obj = JSONObject().apply {
                put("id", s.id)
                put("firstName", s.firstName)
                put("lastName", s.lastName)
                put("groupName", s.groupName)
            }
            studentsJson.put(obj)
        }

        val attendanceJson = JSONArray()
        for (a in attendanceList) {
            val obj = JSONObject().apply {
                put("studentId", a.studentId)
                put("lessonDate", a.lessonDate)
                put("subject", a.subject)
                put("status", a.status)
            }
            attendanceJson.put(obj)
        }

        prefs.edit()
            .putString(KEY_STUDENTS, studentsJson.toString())
            .putString(KEY_ATTENDANCE, attendanceJson.toString())
            .apply()
    }

    // Загрузка списков из JSON при старте
    fun load(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        val studentsStr = prefs.getString(KEY_STUDENTS, null)
        if (studentsStr != null) {
            studentList.clear()
            val array = JSONArray(studentsStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                studentList.add(
                    Student(
                        id = obj.getInt("id"),
                        firstName = obj.getString("firstName"),
                        lastName = obj.getString("lastName"),
                        groupName = obj.getString("groupName")
                    )
                )
            }
        }

        val attendanceStr = prefs.getString(KEY_ATTENDANCE, null)
        if (attendanceStr != null) {
            attendanceList.clear()
            val array = JSONArray(attendanceStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                attendanceList.add(
                    Attendance(
                        studentId = obj.getInt("studentId"),
                        lessonDate = obj.getString("lessonDate"),
                        subject = obj.getString("subject"),
                        status = obj.getString("status")
                    )
                )
            }
        }
    }
}
