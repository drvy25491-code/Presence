package com.example.attendancecontrol

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LessonSetupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lesson_setup)

        val etGroup = findViewById<EditText>(R.id.etGroup)
        val etSubject = findViewById<EditText>(R.id.etSubject)
        val etDate = findViewById<EditText>(R.id.etDate)
        val btnStartLesson = findViewById<Button>(R.id.btnStartLesson)

        // Подставляем текущую дату по умолчанию
        val currentDate = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date())
        etDate.setText(currentDate)

        btnStartLesson.setOnClickListener {
            val group = etGroup.text.toString().trim()
            val subject = etSubject.text.toString().trim()
            val date = etDate.text.toString().trim()

            if (group.isEmpty() || subject.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Заполните все поля занятия!", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, AttendanceActivity::class.java).apply {
                    putExtra("GROUP_NAME", group)
                    putExtra("SUBJECT", subject)
                    putExtra("LESSON_DATE", date)
                }
                startActivity(intent)
            }
        }
    }
}
