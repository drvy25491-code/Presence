package com.example.attendancecontrol

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class GroupsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_groups)
        findViewById<Button>(R.id.btnBackFromGroups).setOnClickListener {
            finish() // Закрывает экран групп и возвращает на главный
        }

        val etGroupName = findViewById<EditText>(R.id.etGroupName)
        val btnCreateGroup = findViewById<Button>(R.id.btnCreateGroup)
        val lvGroups = findViewById<ListView>(R.id.lvGroups)

        // Берем список групп из MainActivity
        val groupNames = MainActivity.groupList.map { it.name }.toMutableList()

        // ТУТ БЫЛА ОШИБКА - убрали "context:"
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, groupNames)
        lvGroups.adapter = adapter

        btnCreateGroup.setOnClickListener {
            val name = etGroupName.text.toString().trim()
            if (name.isNotEmpty()) {
                val newGroup = Group((0..1000).random(), name)
                MainActivity.groupList.add(newGroup)
                groupNames.add(name)
                adapter.notifyDataSetChanged()
                etGroupName.text.clear()
                Toast.makeText(this, "Группа добавлена", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Введите название группы", Toast.LENGTH_SHORT).show()
            }
        }
    }
}