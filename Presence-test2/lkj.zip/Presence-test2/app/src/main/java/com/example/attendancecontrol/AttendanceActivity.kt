package com.example.attendancecontrol

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.attendancecontrol.Student.Companion.attendanceList
import com.example.attendancecontrol.Student.Companion.studentList


class AttendanceActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_attendance)

        val groupName = intent.getStringExtra("GROUP_NAME") ?: ""
        val subject = intent.getStringExtra("SUBJECT") ?: ""
        val lessonDate = intent.getStringExtra("LESSON_DATE") ?: ""

        val tvLessonInfo = findViewById<TextView>(R.id.tvLessonInfo)
        val tvEmptyList = findViewById<TextView>(R.id.tvEmptyList)
        val rvAttendance = findViewById<RecyclerView>(R.id.rvAttendance)
        val btnSave = findViewById<Button>(R.id.btnSaveAttendance)

        tvLessonInfo.text = "Группа: $groupName | $subject ($lessonDate)"

        // Фильтруем студентов по выбранной группе
        val groupStudents = studentList.filter {
            it.groupName.equals(groupName, ignoreCase = true)
        }

        // Проверяем, пустой ли список
        if (groupStudents.isEmpty()) {
            rvAttendance.visibility = View.GONE
            btnSave.visibility = View.GONE
            tvEmptyList.visibility = View.VISIBLE
            return
        }

        // Временное хранилище статусов до нажатия кнопки "Сохранить"
        val currentStatuses = mutableMapOf<Int, String>()
        for (student in groupStudents) {
            // Если отметка за это занятие уже была, подтягиваем её, иначе по умолчанию "Присутствовал"
            val existing = attendanceList.find {
                it.studentId == student.id && it.lessonDate == lessonDate && it.subject == subject
            }
            currentStatuses[student.id] = existing?.status ?: "Присутствовал"
        }

        val adapter = AttendanceAdapter(groupStudents, currentStatuses)
        rvAttendance.layoutManager = LinearLayoutManager(this)
        rvAttendance.adapter = adapter

        btnSave.setOnClickListener {
            for (student in groupStudents) {
                val chosenStatus = currentStatuses[student.id] ?: "Присутствовал"

                // Удаляем старую запись за это занятие, чтобы соблюсти правило 1 отметки
                attendanceList.removeAll {
                    it.studentId == student.id && it.lessonDate == lessonDate && it.subject == subject
                }

                // Сохраняем итоговую отметку
                attendanceList.add(
                    Attendance(
                        studentId = student.id,
                        lessonDate = lessonDate,
                        subject = subject,
                        status = chosenStatus
                    )
                )
            }
            Student.save(this)
            Toast.makeText(this, "Посещаемость сохранена!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}

class AttendanceAdapter(
    private val students: List<Student>,
    private val statusMap: MutableMap<Int, String>
) : RecyclerView.Adapter<AttendanceAdapter.AttendanceViewHolder>() {

    class AttendanceViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvStudentNameAttendance)
        val rgStatus: RadioGroup = view.findViewById(R.id.rgStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AttendanceViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_attendance, parent, false)
        return AttendanceViewHolder(view)
    }

    override fun onBindViewHolder(holder: AttendanceViewHolder, position: Int) {
        val student = students[position]
        holder.tvName.text = "${student.lastName} ${student.firstName}"

        // Сбрасываем слушатель перед установкой состояния при прокрутке списка
        holder.rgStatus.setOnCheckedChangeListener(null)

        when (statusMap[student.id]) {
            "Присутствовал" -> holder.rgStatus.check(R.id.rbPresent)
            "Отсутствовал" -> holder.rgStatus.check(R.id.rbAbsent)
            "Опоздал" -> holder.rgStatus.check(R.id.rbLate)
        }

        holder.rgStatus.setOnCheckedChangeListener { _, checkedId ->
            val newStatus = when (checkedId) {
                R.id.rbPresent -> "Присутствовал"
                R.id.rbAbsent -> "Отсутствовал"
                R.id.rbLate -> "Опоздал"
                else -> "Присутствовал"
            }
            statusMap[student.id] = newStatus
        }
    }

    override fun getItemCount() = students.size
}
